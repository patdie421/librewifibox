#ifndef __const_h
#define __const_h

extern const char *error_str;
extern const char *warning_str;
extern const char *debug_str;
extern const char *default_cfgfile;


#endif
