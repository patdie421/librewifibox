//
//  error.h
//
//  Created by Patrice Dietsch on 17/05/13.
//
//

#ifndef __mea_error_h
#define __mea_error_h


typedef enum mea_error_e
{
   ERROR=-1,
   NOERROR=0
} mea_error_t;

#endif
